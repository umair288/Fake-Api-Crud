# Credentials
This is a Credential saving CRUD app coded in c# with attached mysql database.
Note: Passowrd: hasham56 (you can change password in code, just search for "hasham56" in Entire Solution)

## Setup
 - Step1: Run Xampp Apache and Mysql.
 - Step2: Cut and Paste "credentials" folder in "C:\xampp\mysql\data".
 - Step3: Build and Run.

## Features
 - **Good quality winform GUI**
 - **Stores user information and credentials in database**
 - **Pure CRUD app with Create Read Update and Delete Options**

## Here are some screenshot of Credentials CRUD app.
## Password Protected Page
![](screenshots/screen1.PNG)
## Home Page
![](screenshots/screen2.PNG)
## Information Form Shown
![](screenshots/screen3.PNG)

IF any queries you can ask me i will try to reply as soon as possible!
